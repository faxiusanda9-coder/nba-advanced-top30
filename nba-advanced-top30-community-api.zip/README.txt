NBA 高阶数据 TOP 30 · 无密钥社区 API 版

本项目通过 Vercel 的 /api/advanced 服务端代理公开的 NBA Stats API 2.0 社区测试接口，提供 PER、TS%、USG%、篮板率、助攻率、WS、VORP、OBPM、DBPM 等字段的 TOP 30 排名。无需 Python，也不需要申请 API key。

更新 GitHub 项目
1. 将 index.html 和 api/advanced.js 更新到 GitHub 仓库根目录对应位置（api/advanced.js 保持在 api 文件夹中）。
2. 提交后 Vercel 会自动部署。vercel.json 无需修改。
3. 等 Vercel 部署显示 Ready 后访问网站；或打开 /api/advanced?season=2025-26&type=REG 查看 JSON。

接口参数
- 常规赛：type=REG；季后赛：type=PST。
- 赛季格式为起始年份，例如 2025-26。
- 每个赛季/赛制第一次请求时由后端分页拉取全联盟数据，成功后缓存 30 分钟。

来源与限制
- 数据接口：https://api.server.nbaapi.com/api/playeradvancedstats
- 文档与源码说明：https://github.com/ehammill/nbastats
- 这是无密钥的社区公开测试 API，不是 NBA 官方服务或 Sportradar 服务。项目文档将其标为 public beta；可用性、数据更新频率、字段覆盖和请求限制由该服务维护者决定。
- 本网页会显示数据源说明；若接口关闭或结构变化，页面会提示读取失败。该社区接口文档提供 PER、TS%、usage%、胜利贡献值、VORP 和正负值等字段，未承诺提供 NBA.com PIE。
